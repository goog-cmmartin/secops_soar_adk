import json
import sys
from ScriptResult import EXECUTION_STATE_COMPLETED, EXECUTION_STATE_FAILED
from SiemplifyAction import SiemplifyAction
from SiemplifyUtils import output_handler

try:
    from LogJammerManager import LogJammerManager
except ImportError:
    try:
        from LogJammerManager import LogJammerManager
    except ImportError:
        from LogJammerManager import LogJammerManager

INTEGRATION_NAME = "LogJammer"
SCRIPT_NAME = "Generate Attack Scenario Logs"


@output_handler
def main():
    siemplify = SiemplifyAction()
    siemplify.script_name = SCRIPT_NAME

    status = EXECUTION_STATE_COMPLETED
    output_message = ""
    result_value = False

    try:
        # 1. Integration configuration parameters
        gemini_api_key = siemplify.extract_configuration_param(INTEGRATION_NAME, "Gemini API Key")
        gti_api_key = siemplify.extract_configuration_param(INTEGRATION_NAME, "Google Threat Intelligence API Key")
        sa_json = siemplify.extract_configuration_param(INTEGRATION_NAME, "Service Account JSON")
        workload_identity_email = siemplify.extract_configuration_param(INTEGRATION_NAME, "Workload Identity Email")
        gcp_project_id = siemplify.extract_configuration_param(INTEGRATION_NAME, "GCP Project ID")
        secops_customer_id = siemplify.extract_configuration_param(INTEGRATION_NAME, "SecOps Customer ID")
        secops_region = siemplify.extract_configuration_param(
            INTEGRATION_NAME, "SecOps Region", default_value="us"
        )
        model_name = siemplify.extract_configuration_param(
            INTEGRATION_NAME, "Model Name", default_value="gemini-3.7-flash"
        )

        # 2. Action parameters
        scenario_prompt = siemplify.extract_action_param("Scenario Prompt")
        if not scenario_prompt or not str(scenario_prompt).strip():
            raise ValueError("The 'Scenario Prompt' parameter is required.")

        raw_log_types = siemplify.extract_action_param("Log Types", default_value="")
        log_types = [t.strip().upper() for t in raw_log_types.split(",") if t.strip()] if raw_log_types else None

        rule_identifier = siemplify.extract_action_param("Rule Identifier", default_value="")
        rule_outcome = siemplify.extract_action_param("Rule Outcome", default_value="fire")
        if rule_outcome not in ("fire", "evade", "full-chain"):
            rule_outcome = "fire"

        raw_count = siemplify.extract_action_param("Event Count", default_value="5")
        try:
            event_count = max(1, min(100, int(raw_count)))
        except (ValueError, TypeError):
            event_count = 5

        custom_scenario_name = siemplify.extract_action_param("Scenario Name", default_value="")

        ingest_to_secops_param = siemplify.extract_action_param(
            "Ingest to SecOps", default_value="true", print_value=True
        )
        if isinstance(ingest_to_secops_param, str):
            ingest_to_secops = ingest_to_secops_param.strip().lower() in ("true", "1", "yes")
        elif isinstance(ingest_to_secops_param, bool):
            ingest_to_secops = ingest_to_secops_param
        else:
            ingest_to_secops = True

        enrich_gti_param = siemplify.extract_action_param(
            "Enrich with Google TI", default_value="false", print_value=True
        )
        if isinstance(enrich_gti_param, str):
            enrich_gti = enrich_gti_param.strip().lower() in ("true", "1", "yes")
        elif isinstance(enrich_gti_param, bool):
            enrich_gti = enrich_gti_param
        else:
            enrich_gti = False

        # 3. Instantiate LogJammer Manager
        manager = LogJammerManager(
            gemini_api_key=gemini_api_key,
            gti_api_key=gti_api_key,
            service_account_json=sa_json,
            workload_identity_email=workload_identity_email,
            gcp_project_id=gcp_project_id,
            secops_customer_id=secops_customer_id,
            secops_region=secops_region,
            model_name=model_name,
            logger=siemplify.LOGGER,
        )

        case_id = getattr(siemplify, "case_id", None)
        if custom_scenario_name and str(custom_scenario_name).strip():
            scenario_name = str(custom_scenario_name).strip()
        else:
            scenario_name = f"SOAR_Case_{case_id}_Simulation" if case_id else "SOAR_Simulation"

        # 4. Generate Attack Scenario Logs
        results = manager.generate_scenario(
            scenario_prompt=str(scenario_prompt).strip(),
            log_types=log_types,
            rule_identifier=str(rule_identifier).strip() if rule_identifier else None,
            rule_outcome=rule_outcome,
            count=event_count,
            enrich_gti=enrich_gti,
            ingest_to_secops=ingest_to_secops,
            scenario_name=scenario_name,
        )

        # 5. Output and JSON Attachment
        siemplify.result.add_result_json(results)
        result_value = True

        total_events = results.get("total_events", 0)
        types_str = ", ".join(results.get("log_types", []))
        secops_status = results.get("secops_ingestion", {}).get("status", "SKIPPED")
        ingested_count = results.get("secops_ingestion", {}).get("ingested_count", 0)
        udm_query = results.get("udm_query") or results.get("secops_ingestion", {}).get("udm_query", "")

        output_message = (
            f"Successfully generated {total_events} synthetic security events across log types [{types_str}]. "
            f"SecOps Ingestion Status: {secops_status} ({ingested_count} events ingested). "
            f"UDM Search: {udm_query}"
        )

    except Exception as err:
        import traceback
        tb_str = traceback.format_exc()
        siemplify.LOGGER.error(f"Failed to generate synthetic scenario: {err}\n{tb_str}")
        output_message = f"Error generating synthetic scenario logs: {str(err)}"
        status = EXECUTION_STATE_FAILED
        result_value = False

    siemplify.end(output_message, result_value, status)


if __name__ == "__main__":
    main()
