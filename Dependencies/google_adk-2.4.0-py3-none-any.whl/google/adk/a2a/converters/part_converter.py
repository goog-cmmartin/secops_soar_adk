# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
module containing utilities for conversion between A2A Part and Google GenAI Part
"""

from __future__ import annotations

import base64
from collections.abc import Callable
import logging
from typing import List
from typing import Optional
from typing import Union

from a2a import types as a2a_types
from google.genai import types as genai_types

from ...utils.variant_utils import get_google_llm_variant
from ...utils.variant_utils import GoogleLLMVariant
from ..experimental import a2a_experimental
from .utils import _get_adk_metadata_key

logger = logging.getLogger('google_adk.' + __name__)

A2A_DATA_PART_METADATA_TYPE_KEY = 'type'
A2A_DATA_PART_METADATA_IS_LONG_RUNNING_KEY = 'is_long_running'
A2A_DATA_PART_METADATA_TYPE_FUNCTION_CALL = 'function_call'
A2A_DATA_PART_METADATA_TYPE_FUNCTION_RESPONSE = 'function_response'
A2A_DATA_PART_METADATA_TYPE_CODE_EXECUTION_RESULT = 'code_execution_result'
A2A_DATA_PART_METADATA_TYPE_EXECUTABLE_CODE = 'executable_code'
A2A_DATA_PART_TEXT_MIME_TYPE = 'text/plain'
A2A_DATA_PART_START_TAG = b'<a2a_datapart_json>'
A2A_DATA_PART_END_TAG = b'</a2a_datapart_json>'


A2APartToGenAIPartConverter = Callable[
    [a2a_types.Part], Union[Optional[genai_types.Part], List[genai_types.Part]]
]
GenAIPartToA2APartConverter = Callable[
    [genai_types.Part],
    Union[Optional[a2a_types.Part], List[a2a_types.Part]],
]


@a2a_experimental
def convert_a2a_part_to_genai_part(
    a2a_part: a2a_types.Part,
) -> Optional[genai_types.Part]:
  """Convert an A2A Part to a Google GenAI Part."""

  # part_metadata is only accepted by the Gemini Developer API. In Vertex AI /
  # Enterprise mode it must be omitted to avoid a client-side ValueError.
  def _part_metadata(metadata):
    if get_google_llm_variant() == GoogleLLMVariant.VERTEX_AI:
      return None
    return metadata

  part = a2a_part.root
  if isinstance(part, a2a_types.TextPart):
    thought = None
    if part.metadata:
      thought = part.metadata.get(_get_adk_metadata_key('thought'))
    return genai_types.Part(
        text=part.text,
        thought=thought,
        part_metadata=_part_metadata(part.metadata),
    )

  if isinstance(part, a2a_types.FilePart):
    if isinstance(part.file, a2a_types.FileWithUri):
      return genai_types.Part(
          file_data=genai_types.FileData(
              file_uri=part.file.uri,
              mime_type=part.file.mime_type,
              display_name=part.file.name,
          ),
          part_metadata=_part_metadata(part.metadata),
      )

    elif isinstance(part.file, a2a_types.FileWithBytes):
      return genai_types.Part(
          inline_data=genai_types.Blob(
              data=base64.b64decode(part.file.bytes),
              mime_type=part.file.mime_type,
              display_name=part.file.name,
          ),
          part_metadata=_part_metadata(part.metadata),
      )
    else:
      logger.warning(
          'Cannot convert unsupported file type: %s for A2A part: %s',
          type(part.file),
          a2a_part,
      )
      return None

  if isinstance(part, a2a_types.DataPart):
    # Convert the Data Part to funcall and function response.
    # This is mainly for converting human in the loop and auth request and
    # response.
    # TODO once A2A defined how to service such information, migrate below
    # logic accordingly
    if (
        part.metadata
        and _get_adk_metadata_key(A2A_DATA_PART_METADATA_TYPE_KEY)
        in part.metadata
    ):
      if (
          part.metadata[_get_adk_metadata_key(A2A_DATA_PART_METADATA_TYPE_KEY)]
          == A2A_DATA_PART_METADATA_TYPE_FUNCTION_CALL
      ):
        # Restore thought_signature if present
        thought_signature = None
        thought_sig_key = _get_adk_metadata_key('thought_signature')
        if thought_sig_key in part.metadata:
          sig_value = part.metadata[thought_sig_key]
          if isinstance(sig_value, bytes):
            thought_signature = sig_value
          elif isinstance(sig_value, str):
            try:
              thought_signature = base64.b64decode(sig_value)
            except Exception:
              logger.warning(
                  'Failed to decode thought_signature: %s', sig_value
              )
        return genai_types.Part(
            function_call=genai_types.FunctionCall.model_validate(
                part.data, by_alias=True
            ),
            thought_signature=thought_signature,
            part_metadata=_part_metadata(part.metadata),
        )
      if (
          part.metadata[_get_adk_metadata_key(A2A_DATA_PART_METADATA_TYPE_KEY)]
          == A2A_DATA_PART_METADATA_TYPE_FUNCTION_RESPONSE
      ):
        return genai_types.Part(
            function_response=genai_types.FunctionResponse.model_validate(
                part.data, by_alias=True
            ),
            part_metadata=_part_metadata(part.metadata),
        )
      if (
          part.metadata[_get_adk_metadata_key(A2A_DATA_PART_METADATA_TYPE_KEY)]
          == A2A_DATA_PART_METADATA_TYPE_CODE_EXECUTION_RESULT
      ):
        return genai_types.Part(
            code_execution_result=genai_types.CodeExecutionResult.model_validate(
                part.data, by_alias=True
            ),
            part_metadata=_part_metadata(part.metadata),
        )
      if (
          part.metadata[_get_adk_metadata_key(A2A_DATA_PART_METADATA_TYPE_KEY)]
          == A2A_DATA_PART_METADATA_TYPE_EXECUTABLE_CODE
      ):
        return genai_types.Part(
            executable_code=genai_types.ExecutableCode.model_validate(
                part.data, by_alias=True
            ),
            part_metadata=_part_metadata(part.metadata),
        )
    return genai_types.Part(
        inline_data=genai_types.Blob(
            data=A2A_DATA_PART_START_TAG
            + part.model_dump_json(by_alias=True, exclude_none=True).encode(
                'utf-8'
            )
            + A2A_DATA_PART_END_TAG,
            mime_type=A2A_DATA_PART_TEXT_MIME_TYPE,
        ),
        part_metadata=_part_metadata(part.metadata),
    )

  logger.warning(
      'Cannot convert unsupported part type: %s for A2A part: %s',
      type(part),
      a2a_part,
  )
  return None


@a2a_experimental
def convert_genai_part_to_a2a_part(
    part: genai_types.Part,
) -> Optional[a2a_types.Part]:
  """Convert a Google GenAI Part to an A2A Part."""

  def add_metadata_to_a2a_part(
      a2a_part: a2a_types.Part,
      metadata: dict[str, Any],
  ) -> None:
    """Adds metadata to an A2A part."""
    if a2a_part.metadata is None:
      a2a_part.metadata = {}
    a2a_part.metadata.update(metadata)

  if part.text is not None:
    a2a_part = a2a_types.TextPart(text=part.text)
    if part.thought is not None:
      a2a_part.metadata = {_get_adk_metadata_key('thought'): part.thought}
    if part.part_metadata:
      add_metadata_to_a2a_part(a2a_part, part.part_metadata)
    return a2a_types.Part(root=a2a_part)

  if part.file_data:
    a2a_part = a2a_types.FilePart(
        file=a2a_types.FileWithUri(
            uri=part.file_data.file_uri,
            mime_type=part.file_data.mime_type,
            name=part.file_data.display_name,
        )
    )
    if part.part_metadata:
      add_metadata_to_a2a_part(a2a_part, part.part_metadata)
    return a2a_types.Part(root=a2a_part)

  if part.inline_data:
    if (
        part.inline_data.mime_type == A2A_DATA_PART_TEXT_MIME_TYPE
        and part.inline_data.data is not None
        and part.inline_data.data.startswith(A2A_DATA_PART_START_TAG)
        and part.inline_data.data.endswith(A2A_DATA_PART_END_TAG)
    ):
      a2a_part = a2a_types.DataPart.model_validate_json(
          part.inline_data.data[
              len(A2A_DATA_PART_START_TAG) : -len(A2A_DATA_PART_END_TAG)
          ]
      )
      if part.part_metadata:
        add_metadata_to_a2a_part(a2a_part, part.part_metadata)
      return a2a_types.Part(root=a2a_part)
    # The default case for inline_data is to convert it to FileWithBytes.
    a2a_part = a2a_types.FilePart(
        file=a2a_types.FileWithBytes(
            bytes=base64.b64encode(part.inline_data.data).decode('utf-8'),
            mime_type=part.inline_data.mime_type,
            name=part.inline_data.display_name,
        )
    )

    if part.video_metadata:
      a2a_part.metadata = {
          _get_adk_metadata_key(
              'video_metadata'
          ): part.video_metadata.model_dump(by_alias=True, exclude_none=True)
      }

    if part.part_metadata:
      add_metadata_to_a2a_part(a2a_part, part.part_metadata)

    return a2a_types.Part(root=a2a_part)

  # Convert the funcall and function response to A2A DataPart.
  # This is mainly for converting human in the loop and auth request and
  # response.
  # TODO once A2A defined how to service such information, migrate below
  # logic accordingly
  if part.function_call:
    fc_metadata = {
        _get_adk_metadata_key(
            A2A_DATA_PART_METADATA_TYPE_KEY
        ): A2A_DATA_PART_METADATA_TYPE_FUNCTION_CALL
    }
    # Preserve thought_signature if present
    if part.thought_signature is not None:
      fc_metadata[_get_adk_metadata_key('thought_signature')] = (
          base64.b64encode(part.thought_signature).decode('utf-8')
      )
    if part.part_metadata:
      fc_metadata.update(part.part_metadata)
    return a2a_types.Part(
        root=a2a_types.DataPart(
            data=part.function_call.model_dump(
                by_alias=True, exclude_none=True
            ),
            metadata=fc_metadata,
        )
    )

  if part.function_response:
    fr_metadata = {
        _get_adk_metadata_key(
            A2A_DATA_PART_METADATA_TYPE_KEY
        ): A2A_DATA_PART_METADATA_TYPE_FUNCTION_RESPONSE
    }
    if part.part_metadata:
      fr_metadata.update(part.part_metadata)
    return a2a_types.Part(
        root=a2a_types.DataPart(
            data=part.function_response.model_dump(
                by_alias=True, exclude_none=True
            ),
            metadata=fr_metadata,
        )
    )

  if part.code_execution_result:
    cer_metadata = {
        _get_adk_metadata_key(
            A2A_DATA_PART_METADATA_TYPE_KEY
        ): A2A_DATA_PART_METADATA_TYPE_CODE_EXECUTION_RESULT
    }
    if part.part_metadata:
      cer_metadata.update(part.part_metadata)
    return a2a_types.Part(
        root=a2a_types.DataPart(
            data=part.code_execution_result.model_dump(
                by_alias=True, exclude_none=True
            ),
            metadata=cer_metadata,
        )
    )

  if part.executable_code:
    ec_metadata = {
        _get_adk_metadata_key(
            A2A_DATA_PART_METADATA_TYPE_KEY
        ): A2A_DATA_PART_METADATA_TYPE_EXECUTABLE_CODE
    }
    if part.part_metadata:
      ec_metadata.update(part.part_metadata)
    return a2a_types.Part(
        root=a2a_types.DataPart(
            data=part.executable_code.model_dump(
                by_alias=True, exclude_none=True
            ),
            metadata=ec_metadata,
        )
    )

  logger.warning(
      'Cannot convert unsupported part for Google GenAI part: %s',
      part,
  )
  return None
